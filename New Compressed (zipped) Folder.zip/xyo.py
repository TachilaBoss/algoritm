def XYO():
    print("Введите любой текст содержащий XY,для поиска растоя между X и Y:")
    text= input()
    index1 = text.find("X")
    index2 = text.find("Y")
    if index1 != -1 and index2 != -1:
        character_count = abs((index1 - index2)+1)
        print(character_count)
    else:
        print(False)
XYO()